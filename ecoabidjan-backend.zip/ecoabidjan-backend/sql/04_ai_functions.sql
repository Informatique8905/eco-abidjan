-- Analyse IA des photos de dépôts sauvages : AI_COMPLETE (vision) + AI_CLASSIFY + AI_EXTRACT
USE SCHEMA ECOABIDJAN.CORE;

-- Dépôt côté serveur d'une photo (base64) dans @PHOTOS : évite le PUT client
CREATE OR REPLACE PROCEDURE UPLOAD_PHOTO(P_PATH STRING, P_B64 STRING)
RETURNS STRING
LANGUAGE PYTHON
RUNTIME_VERSION = '3.11'
PACKAGES = ('snowflake-snowpark-python')
HANDLER = 'run'
AS
$$
import base64, io

def run(session, p_path, p_b64):
    data = base64.b64decode(p_b64.split(',')[-1])
    session.file.put_stream(io.BytesIO(data), f"@ECOABIDJAN.CORE.PHOTOS/{p_path}",
                            auto_compress=False, overwrite=True)
    session.sql("ALTER STAGE ECOABIDJAN.CORE.PHOTOS REFRESH").collect()
    return p_path
$$;

CREATE OR REPLACE PROCEDURE ANALYZE_REPORT(P_REPORT_ID STRING)
RETURNS VARIANT
LANGUAGE SQL
AS
$$
DECLARE
  v_path STRING;
  v_desc STRING;
  v_cat VARIANT;
  v_ext VARIANT;
  v_weight FLOAT;
BEGIN
  SELECT PHOTO_PATH INTO :v_path FROM REPORTS WHERE REPORT_ID = :P_REPORT_ID;

  -- 1) Vision : description détaillée du dépôt
  SELECT AI_COMPLETE(
           'claude-sonnet-4-5',
           'Tu es un expert en gestion des déchets à Abidjan. Décris précisément ce dépôt sauvage : '
           || 'liste chaque type d''objet visible, les matériaux (plastique, carton, aluminium, verre, organique, textile, gravats...), '
           || 'le volume approximatif en m3 et une estimation du poids total en kg en justifiant. '
           || 'Indique aussi la part valorisable (recyclable). Réponds en français, de façon concise.',
           TO_FILE('@ECOABIDJAN.CORE.PHOTOS', :v_path))
    INTO :v_desc;

  -- 2) Catégorie principale
  SELECT AI_CLASSIFY(:v_desc,
           ['Plastiques', 'Ordures ménagères', 'Cartons/Papiers', 'Métaux/Aluminium',
            'Gravats/BTP', 'Encombrants', 'Déchets verts', 'Mixte'])
    INTO :v_cat;

  -- 3) Extraction structurée
  SELECT AI_EXTRACT(
           text => :v_desc,
           responseFormat => {
             'objets': 'Liste des objets identifiés, séparés par des virgules',
             'materiaux': 'Liste des matériaux identifiés, séparés par des virgules',
             'poids_kg': 'Poids total estimé en kilogrammes, nombre uniquement',
             'volume_m3': 'Volume estimé en m3, nombre uniquement',
             'part_recyclable': 'Pourcentage valorisable estimé, nombre uniquement'
           })
    INTO :v_ext;

  v_weight := TRY_TO_DOUBLE(REPLACE(REGEXP_SUBSTR(:v_ext:response:poids_kg::STRING, '[0-9]+([.,][0-9]+)?'), ',', '.'));

  UPDATE REPORTS SET
    AI_DESCRIPTION = :v_desc,
    AI_CATEGORY    = :v_cat:labels[0]::STRING,
    AI_OBJECTS     = IFF(IS_ARRAY(:v_ext:response:objets), :v_ext:response:objets::ARRAY, SPLIT(:v_ext:response:objets::STRING, ',')),
    AI_MATERIALS   = IFF(IS_ARRAY(:v_ext:response:materiaux), :v_ext:response:materiaux::ARRAY, SPLIT(:v_ext:response:materiaux::STRING, ',')),
    AI_WEIGHT_KG   = :v_weight,
    AI_RAW         = OBJECT_CONSTRUCT('classify', :v_cat, 'extract', :v_ext),
    STATUS         = 'ANALYSE'
  WHERE REPORT_ID = :P_REPORT_ID;

  RETURN OBJECT_CONSTRUCT(
    'report_id', :P_REPORT_ID,
    'description', :v_desc,
    'categorie', :v_cat:labels[0]::STRING,
    'extraction', :v_ext:response,
    'poids_kg', :v_weight);
END;
$$;
