-- Module IA : planification de la tournée de collecte des commerçants à gros volume
USE SCHEMA ECOABIDJAN.CORE;

CREATE OR REPLACE PROCEDURE PLAN_COLLECTION_ROUTE(P_COMMUNE STRING, P_MAX_STOPS INT, P_DAYS INT)
RETURNS VARIANT
LANGUAGE PYTHON
RUNTIME_VERSION = '3.11'
PACKAGES = ('snowflake-snowpark-python')
HANDLER = 'run'
AS
$$
import json, math

def haversine(a, b):
    r = 6371.0
    lat1, lon1, lat2, lon2 = map(math.radians, (a[1], a[0], b[1], b[0]))
    h = math.sin((lat2-lat1)/2)**2 + math.cos(lat1)*math.cos(lat2)*math.sin((lon2-lon1)/2)**2
    return 2*r*math.asin(math.sqrt(h))

def tour_length(pts, order):
    return sum(haversine(pts[order[i]], pts[order[i+1]]) for i in range(len(order)-1))

def nearest_neighbor(pts):
    # 0 = dépôt ; retour au dépôt en fin de tournée
    unvisited, order = set(range(1, len(pts))), [0]
    while unvisited:
        last = order[-1]
        nxt = min(unvisited, key=lambda j: haversine(pts[last], pts[j]))
        order.append(nxt); unvisited.remove(nxt)
    return order + [0]

def two_opt(pts, order):
    improved = True
    while improved:
        improved = False
        for i in range(1, len(order)-2):
            for k in range(i+1, len(order)-1):
                new = order[:i] + order[i:k+1][::-1] + order[k+1:]
                if tour_length(pts, new) < tour_length(pts, order) - 1e-9:
                    order, improved = new, True
    return order

def run(session, p_commune, p_max_stops, p_days):
    cfg = {r['KEY']: r['VALUE'] for r in session.sql("SELECT KEY, VALUE FROM ECOABIDJAN.CORE.CONFIG").collect()}
    y = cfg['WEIGHT_THRESHOLD_Y']
    commune_filter = "" if not p_commune or p_commune.upper() == 'TOUTES' else "AND u.COMMUNE = ?"
    params = [y, int(p_days or 7)] + ([p_commune] if commune_filter else []) + [int(p_max_stops or 12)]
    rows = session.sql(f"""
        SELECT u.USER_ID, u.NAME, u.COMMUNE, ST_X(u.LOCATION) LON, ST_Y(u.LOCATION) LAT,
               SUM(d.WEIGHT_KG) VOLUME_KG,
               LISTAGG(DISTINCT d.MATERIAL, ', ') MATERIALS
          FROM ECOABIDJAN.CORE.USERS u
          JOIN ECOABIDJAN.CORE.DECLARATIONS d ON d.USER_ID = u.USER_ID
         WHERE u.USER_TYPE = 'COMMERCANT' AND d.WEIGHT_KG > ?
           AND (d.STATUS = 'A_COLLECTER' OR d.DECLARED_AT >= DATEADD('day', -?, CURRENT_TIMESTAMP()))
           {commune_filter}
         GROUP BY 1,2,3,4,5
         ORDER BY VOLUME_KG DESC
         LIMIT ?""", params=params).collect()
    if not rows:
        return {"stops": [], "total_km": 0, "message": "Aucun commerçant à gros volume sur la période"}

    depot = (cfg['DEPOT_LON'], cfg['DEPOT_LAT'])
    pts = [depot] + [(r['LON'], r['LAT']) for r in rows]
    naive = list(range(len(pts))) + [0]
    order = two_opt(pts, nearest_neighbor(pts))
    km = tour_length(pts, order)
    naive_km = tour_length(pts, naive)
    total_kg = sum(float(r['VOLUME_KG']) for r in rows)
    cost = km * cfg['TRUCK_COST_PER_KM'] + total_kg * cfg['COLLECT_COST_PER_KG']

    stops = []
    for rank, idx in enumerate(order[1:-1], start=1):
        r = rows[idx-1]
        stops.append({"order": rank, "user_id": r['USER_ID'], "name": r['NAME'], "commune": r['COMMUNE'],
                      "lon": r['LON'], "lat": r['LAT'], "volume_kg": round(float(r['VOLUME_KG']), 1),
                      "materials": r['MATERIALS'],
                      "leg_km": round(haversine(pts[order[rank-1]], pts[idx]), 2)})

    summary = None
    prompt = ("Tu es le planificateur logistique d'EcoAbidjan. Voici une tournée optimisée (algorithme plus proche voisin + 2-opt) "
              f"au départ du centre de tri de Treichville : {len(stops)} arrêts, {km:.1f} km (contre {naive_km:.1f} km sans optimisation), "
              f"{total_kg:.0f} kg à collecter, coût estimé {cost:.0f} FCFA. Arrêts : "
              + "; ".join(f"{s['order']}. {s['name']} ({s['commune']}, {s['volume_kg']} kg)" for s in stops)
              + ". Rédige en français une note opérationnelle courte (5 lignes max) : créneau horaire conseillé en tenant compte du trafic "
                "abidjanais, type et capacité de camion, points d'attention.")
    for model in ('claude-sonnet-4-5', 'pixtral-large', 'mistral-large2', 'llama3.1-70b'):
        try:
            summary = session.sql("SELECT AI_COMPLETE(?, ?) S", params=[model, prompt]).collect()[0]['S']
            break
        except Exception as e:
            summary = f"Résumé IA indisponible ({str(e)[:120]})"

    return {"depot": {"lon": depot[0], "lat": depot[1], "name": "Centre de tri Treichville"},
            "stops": stops, "total_km": round(km, 2), "naive_km": round(naive_km, 2),
            "gain_pct": round(100 * (1 - km / naive_km), 1) if naive_km else 0,
            "total_kg": round(total_kg, 1), "estimated_cost_fcfa": round(cost),
            "ai_summary": summary}
$$;
