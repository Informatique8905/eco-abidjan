-- Jeu de données synthétique : 500 ménages, 200 commerçants, 6 communes (GENERATOR)
USE SCHEMA ECOABIDJAN.CORE;

-- Ménages
INSERT INTO USERS (USER_ID, USER_TYPE, NAME, PHONE, COMMUNE, LOCATION, POINTS_BALANCE)
WITH g AS (SELECT SEQ4() + 1 AS n FROM TABLE(GENERATOR(ROWCOUNT => 500)))
SELECT 'M' || LPAD(g.n, 4, '0'), 'MENAGE',
       'Ménage ' || ARRAY_CONSTRUCT('Koné','Kouassi','Traoré','Yao','Bamba','Ouattara','Diabaté','Konan','Coulibaly','N''Guessan')[MOD(g.n,10)] || ' #' || g.n,
       '+225 07' || LPAD(UNIFORM(0, 99999999, RANDOM()), 8, '0'),
       c.NAME,
       ST_MAKEPOINT(ST_X(c.CENTER) + UNIFORM(-0.018::FLOAT, 0.018::FLOAT, RANDOM()),
                    ST_Y(c.CENTER) + UNIFORM(-0.014::FLOAT, 0.014::FLOAT, RANDOM())),
       0
FROM g JOIN COMMUNES c ON c.COMMUNE_ID = MOD(g.n, 6) + 1;

-- Commerçants (maquis, supermarchés, grossistes, restaurants...)
INSERT INTO USERS (USER_ID, USER_TYPE, NAME, PHONE, COMMUNE, LOCATION, POINTS_BALANCE)
WITH g AS (SELECT SEQ4() + 1 AS n FROM TABLE(GENERATOR(ROWCOUNT => 200)))
SELECT 'C' || LPAD(g.n, 4, '0'), 'COMMERCANT',
       ARRAY_CONSTRUCT('Maquis','Supermarché','Grossiste','Restaurant','Boutique','Cave','Pâtisserie','Quincaillerie')[MOD(g.n,8)] || ' ' || c.NAME || ' #' || g.n,
       '+225 05' || LPAD(UNIFORM(0, 99999999, RANDOM()), 8, '0'),
       c.NAME,
       ST_MAKEPOINT(ST_X(c.CENTER) + UNIFORM(-0.02::FLOAT, 0.02::FLOAT, RANDOM()),
                    ST_Y(c.CENTER) + UNIFORM(-0.016::FLOAT, 0.016::FLOAT, RANDOM())),
       0
FROM g JOIN COMMUNES c ON c.COMMUNE_ID = MOD(g.n, 6) + 1;

-- Points relais : 3 magasins partenaires par commune
INSERT INTO RELAY_POINTS
WITH g AS (SELECT SEQ4() AS n FROM TABLE(GENERATOR(ROWCOUNT => 18)))
SELECT 'R' || LPAD(g.n + 1, 3, '0'),
       ARRAY_CONSTRUCT('Supérette Éco','Prosuma Relais','Station Recyclage')[FLOOR(g.n / 6)] || ' ' || c.NAME,
       c.NAME,
       ST_MAKEPOINT(ST_X(c.CENTER) + UNIFORM(-0.01::FLOAT, 0.01::FLOAT, RANDOM()),
                    ST_Y(c.CENTER) + UNIFORM(-0.01::FLOAT, 0.01::FLOAT, RANDOM()))
FROM g JOIN COMMUNES c ON c.COMMUNE_ID = MOD(g.n, 6) + 1;

-- Historique 30 jours : ménages (petits apports, < Y) -> points ; commerçants (> Y) -> rémunération
INSERT INTO DECLARATIONS (DECL_ID, USER_ID, MATERIAL, WEIGHT_KG, DECLARED_AT, CHANNEL, AMOUNT_FCFA, POINTS, RELAY_ID, STATUS)
WITH y AS (SELECT VALUE AS Y FROM CONFIG WHERE KEY = 'WEIGHT_THRESHOLD_Y'),
     ppk AS (SELECT VALUE AS P FROM CONFIG WHERE KEY = 'POINTS_PER_KG'),
     raw AS (
       SELECT u.USER_ID, u.USER_TYPE, u.COMMUNE,
              ARRAY_CONSTRUCT('CARTON','PLASTIQUE','ALUMINIUM')[UNIFORM(0, 2, RANDOM())]::STRING AS MATERIAL,
              ROUND(IFF(u.USER_TYPE = 'MENAGE', UNIFORM(0.5::FLOAT, 15::FLOAT, RANDOM()),
                                                UNIFORM(25::FLOAT, 350::FLOAT, RANDOM())), 1) AS WEIGHT_KG,
              DATEADD('minute', -UNIFORM(0, 43200, RANDOM()), CURRENT_TIMESTAMP())::TIMESTAMP_NTZ AS TS
       FROM USERS u, TABLE(GENERATOR(ROWCOUNT => 6))      -- 6 apports par usager en moyenne
     )
SELECT UUID_STRING(), r.USER_ID, r.MATERIAL, r.WEIGHT_KG, r.TS,
       IFF(r.WEIGHT_KG > y.Y, 'REMUNERATION', 'POINTS'),
       IFF(r.WEIGHT_KG > y.Y, ROUND(r.WEIGHT_KG * p.PRICE_PER_KG, 0), 0),
       IFF(r.WEIGHT_KG > y.Y, 0, ROUND(r.WEIGHT_KG * ppk.P)),
       IFF(r.WEIGHT_KG > y.Y, NULL, rl.RID),
       'COMPLETED'
FROM raw r CROSS JOIN y CROSS JOIN ppk
JOIN PRICES p ON p.MATERIAL = r.MATERIAL
LEFT JOIN (SELECT COMMUNE, MIN(RELAY_ID) AS RID FROM RELAY_POINTS GROUP BY COMMUNE) rl ON rl.COMMUNE = r.COMMUNE;

INSERT INTO PAYMENTS (USER_ID, DECL_ID, AMOUNT_FCFA, TS)
SELECT USER_ID, DECL_ID, AMOUNT_FCFA, DECLARED_AT FROM DECLARATIONS WHERE CHANNEL = 'REMUNERATION';

UPDATE USERS u SET POINTS_BALANCE = s.PTS
FROM (SELECT USER_ID, SUM(POINTS) AS PTS FROM DECLARATIONS GROUP BY USER_ID) s
WHERE u.USER_ID = s.USER_ID;

-- 120 signalements historiques (analyse IA simulée, sans photo)
INSERT INTO REPORTS (REPORT_ID, USER_ID, LOCATION, COMMUNE, PHOTO_PATH, REPORTED_AT, AI_DESCRIPTION, AI_CATEGORY, AI_OBJECTS, AI_MATERIALS, AI_WEIGHT_KG, STATUS)
WITH g AS (SELECT SEQ4() + 1 AS n, UNIFORM(0, 4, RANDOM()) AS k FROM TABLE(GENERATOR(ROWCOUNT => 120)))
SELECT UUID_STRING(), 'M' || LPAD(UNIFORM(1, 500, RANDOM()), 4, '0'),
       ST_MAKEPOINT(ST_X(c.CENTER) + UNIFORM(-0.02::FLOAT, 0.02::FLOAT, RANDOM()),
                    ST_Y(c.CENTER) + UNIFORM(-0.016::FLOAT, 0.016::FLOAT, RANDOM())),
       c.NAME, NULL,
       DATEADD('minute', -UNIFORM(0, 43200, RANDOM()), CURRENT_TIMESTAMP())::TIMESTAMP_NTZ,
       ARRAY_CONSTRUCT('Tas de sacs plastiques et bouteilles en bord de caniveau',
                       'Dépôt d''ordures ménagères mélangées près d''un marché',
                       'Gravats et déchets de chantier sur un terrain vague',
                       'Cartons et emballages abandonnés derrière des commerces',
                       'Encombrants (matelas, meubles cassés) sur le trottoir')[g.k],
       ARRAY_CONSTRUCT('Plastiques','Ordures ménagères','Gravats/BTP','Cartons/Papiers','Encombrants')[g.k],
       ARRAY_CONSTRUCT(ARRAY_CONSTRUCT('sacs','bouteilles'), ARRAY_CONSTRUCT('restes alimentaires','sacs'),
                       ARRAY_CONSTRUCT('briques','ciment'), ARRAY_CONSTRUCT('cartons','emballages'),
                       ARRAY_CONSTRUCT('matelas','chaises'))[g.k],
       ARRAY_CONSTRUCT(ARRAY_CONSTRUCT('plastique'), ARRAY_CONSTRUCT('organique','plastique'),
                       ARRAY_CONSTRUCT('minéral'), ARRAY_CONSTRUCT('carton','papier'),
                       ARRAY_CONSTRUCT('textile','bois','métal'))[g.k],
       ROUND(UNIFORM(20::FLOAT, 800::FLOAT, RANDOM()), 0),
       ARRAY_CONSTRUCT('NOUVEAU','ANALYSE','PLANIFIE','TRAITE')[UNIFORM(0, 3, RANDOM())]
FROM g JOIN COMMUNES c ON c.COMMUNE_ID = MOD(g.n, 6) + 1;
