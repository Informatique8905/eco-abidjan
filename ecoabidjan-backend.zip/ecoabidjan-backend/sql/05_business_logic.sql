-- Parcours B : déclaration de déchets recyclables, seuil Y, rémunération ou points
USE SCHEMA ECOABIDJAN.CORE;

CREATE OR REPLACE PROCEDURE PROCESS_DECLARATION(P_USER_ID STRING, P_MATERIAL STRING, P_WEIGHT_KG FLOAT)
RETURNS VARIANT
LANGUAGE SQL
AS
$$
DECLARE
  v_y FLOAT;
  v_price FLOAT;
  v_ppk FLOAT;
  v_decl STRING DEFAULT UUID_STRING();
  v_amount FLOAT;
  v_points NUMBER;
  v_balance NUMBER;
  v_relay_id STRING;
  v_relay_name STRING;
  v_relay_dist FLOAT;
  v_relay_lon FLOAT;
  v_relay_lat FLOAT;
BEGIN
  SELECT VALUE INTO :v_y FROM CONFIG WHERE KEY = 'WEIGHT_THRESHOLD_Y';
  SELECT VALUE INTO :v_ppk FROM CONFIG WHERE KEY = 'POINTS_PER_KG';
  SELECT PRICE_PER_KG INTO :v_price FROM PRICES WHERE MATERIAL = UPPER(:P_MATERIAL);

  IF (P_WEIGHT_KG > v_y) THEN
    -- Gros volume (commerçant) : rémunération directe + mise en tournée de collecte
    v_amount := ROUND(P_WEIGHT_KG * v_price, 0);
    INSERT INTO DECLARATIONS (DECL_ID, USER_ID, MATERIAL, WEIGHT_KG, CHANNEL, AMOUNT_FCFA, STATUS)
      VALUES (:v_decl, :P_USER_ID, UPPER(:P_MATERIAL), :P_WEIGHT_KG, 'REMUNERATION', :v_amount, 'A_COLLECTER');
    INSERT INTO PAYMENTS (USER_ID, DECL_ID, AMOUNT_FCFA) VALUES (:P_USER_ID, :v_decl, :v_amount);
    RETURN OBJECT_CONSTRUCT('decl_id', :v_decl, 'channel', 'REMUNERATION', 'threshold_y', :v_y,
                            'material', UPPER(:P_MATERIAL), 'weight_kg', :P_WEIGHT_KG,
                            'price_per_kg', :v_price, 'amount_fcfa', :v_amount);
  ELSE
    -- Petit volume (ménage) : orientation vers le point relais le plus proche
    v_points := ROUND(P_WEIGHT_KG * v_ppk);
    SELECT r.RELAY_ID, r.NAME, ROUND(ST_DISTANCE(r.LOCATION, u.LOCATION)), ST_X(r.LOCATION), ST_Y(r.LOCATION), u.POINTS_BALANCE
      INTO :v_relay_id, :v_relay_name, :v_relay_dist, :v_relay_lon, :v_relay_lat, :v_balance
      FROM RELAY_POINTS r, USERS u
     WHERE u.USER_ID = :P_USER_ID
     ORDER BY ST_DISTANCE(r.LOCATION, u.LOCATION) LIMIT 1;
    INSERT INTO DECLARATIONS (DECL_ID, USER_ID, MATERIAL, WEIGHT_KG, CHANNEL, POINTS, RELAY_ID, STATUS)
      VALUES (:v_decl, :P_USER_ID, UPPER(:P_MATERIAL), :P_WEIGHT_KG, 'POINTS', :v_points, :v_relay_id, 'PENDING_SCAN');
    RETURN OBJECT_CONSTRUCT('decl_id', :v_decl, 'channel', 'POINTS', 'threshold_y', :v_y,
                            'material', UPPER(:P_MATERIAL), 'weight_kg', :P_WEIGHT_KG,
                            'points_pending', :v_points, 'balance_current', :v_balance,
                            'relay', OBJECT_CONSTRUCT('id', :v_relay_id, 'name', :v_relay_name,
                                                      'distance_m', :v_relay_dist, 'lon', :v_relay_lon, 'lat', :v_relay_lat));
  END IF;
END;
$$;

-- Simulation du scan par le magasin relais : crédit instantané des points
CREATE OR REPLACE PROCEDURE SCAN_AT_RELAY(P_DECL_ID STRING)
RETURNS VARIANT
LANGUAGE SQL
AS
$$
DECLARE
  v_user STRING;
  v_points NUMBER;
  v_relay STRING;
  v_status STRING;
  v_before NUMBER;
  v_after NUMBER;
  v_pval FLOAT;
BEGIN
  SELECT USER_ID, POINTS, RELAY_ID, STATUS INTO :v_user, :v_points, :v_relay, :v_status
    FROM DECLARATIONS WHERE DECL_ID = :P_DECL_ID;
  IF (v_status <> 'PENDING_SCAN') THEN
    RETURN OBJECT_CONSTRUCT('error', 'Déclaration déjà scannée ou non éligible');
  END IF;
  SELECT POINTS_BALANCE INTO :v_before FROM USERS WHERE USER_ID = :v_user;
  SELECT VALUE INTO :v_pval FROM CONFIG WHERE KEY = 'POINT_VALUE_FCFA';
  v_after := v_before + v_points;

  UPDATE USERS SET POINTS_BALANCE = :v_after WHERE USER_ID = :v_user;
  UPDATE DECLARATIONS SET STATUS = 'COMPLETED' WHERE DECL_ID = :P_DECL_ID;
  INSERT INTO POINTS_LEDGER (USER_ID, DECL_ID, RELAY_ID, BALANCE_BEFORE, DELTA, BALANCE_AFTER)
    VALUES (:v_user, :P_DECL_ID, :v_relay, :v_before, :v_points, :v_after);

  RETURN OBJECT_CONSTRUCT('decl_id', :P_DECL_ID, 'user_id', :v_user, 'relay_id', :v_relay,
                          'balance_before', :v_before, 'points_added', :v_points, 'balance_after', :v_after,
                          'voucher_value_before_fcfa', :v_before * :v_pval,
                          'voucher_value_after_fcfa', :v_after * :v_pval);
END;
$$;
