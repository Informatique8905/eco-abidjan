export default function Home() {
  return <pre>EcoAbidjan API : /api/reports, /api/declarations, /api/scan, /api/route-plan, /api/kpis, /api/users, /api/config</pre>;
}
