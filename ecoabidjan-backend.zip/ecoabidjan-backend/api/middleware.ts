import { NextRequest, NextResponse } from 'next/server';

// Réponse aux requêtes CORS préliminaires (OPTIONS) des frontends externes
export function middleware(req: NextRequest) {
  if (req.method === 'OPTIONS') {
    return new NextResponse(null, {
      status: 204,
      headers: {
        'Access-Control-Allow-Origin': process.env.CORS_ORIGIN || '*',
        'Access-Control-Allow-Methods': 'GET,POST,OPTIONS',
        'Access-Control-Allow-Headers': 'Content-Type',
      },
    });
  }
  return NextResponse.next();
}

export const config = { matcher: '/api/:path*' };
