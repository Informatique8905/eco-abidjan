/** @type {import('next').NextConfig} */
const nextConfig = {
  experimental: { serverComponentsExternalPackages: ['snowflake-sdk'] },
  async headers() {
    // CORS : autorise un frontend externe (définir CORS_ORIGIN en production)
    return [{ source: '/api/:path*', headers: [
      { key: 'Access-Control-Allow-Origin', value: process.env.CORS_ORIGIN || '*' },
      { key: 'Access-Control-Allow-Methods', value: 'GET,POST,OPTIONS' },
      { key: 'Access-Control-Allow-Headers', value: 'Content-Type' },
    ] }];
  },
};
export default nextConfig;
