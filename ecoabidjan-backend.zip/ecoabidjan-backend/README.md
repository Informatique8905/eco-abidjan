# EcoAbidjan — Backend

Backend seul d'EcoAbidjan : **Snowflake** (données, GEOGRAPHY, stage photos, Cortex AI, logique métier) et une **API REST** Node.js (Next.js en mode API) utilisable par n'importe quel frontend (web, mobile, Postman).

```
ecoabidjan-backend/
├─ sql/                 scripts Snowflake 01 → 07
├─ scripts/deploy_sql.py
└─ api/                 API REST (port 4000)
   ├─ app/api/*/route.ts
   ├─ lib/snowflake.ts
   └─ middleware.ts     CORS
```

## 1. Snowflake
Activer Cortex (ACCOUNTADMIN, une fois) :
```sql
GRANT USE AI FUNCTIONS ON ACCOUNT TO ROLE ACCOUNTADMIN;
ALTER ACCOUNT SET CORTEX_ENABLED_CROSS_REGION = 'ANY_REGION';  -- si claude-sonnet-4-5 est absent de votre région
```
Déployer :
```bash
pip install snowflake-connector-python
export SNOWFLAKE_ACCOUNT=MYORG-MYACCOUNT SNOWFLAKE_USER=moi SNOWFLAKE_PASSWORD=*** SNOWFLAKE_ROLE=ACCOUNTADMIN SNOWFLAKE_WAREHOUSE=COMPUTE_WH
python scripts/deploy_sql.py              # tout (réinitialise les données)
python scripts/deploy_sql.py --skip-data  # procédures et vues uniquement
```

| Objet (ECOABIDJAN.CORE) | Rôle |
|---|---|
| USERS, COMMUNES, RELAY_POINTS, REPORTS, DECLARATIONS, PAYMENTS, POINTS_LEDGER | Tables (localisations GEOGRAPHY) |
| @PHOTOS | Stage des photos (SSE, directory table) |
| CONFIG, PRICES | Seuil Y (20 kg), points/kg, coûts ; prix carton 200 / plastique 250 / aluminium 300 F/kg |
| UPLOAD_PHOTO(path, base64) | Écrit la photo dans @PHOTOS |
| ANALYZE_REPORT(report_id) | AI_COMPLETE (vision) + AI_CLASSIFY + AI_EXTRACT → objets, matériaux, poids |
| PROCESS_DECLARATION(user, matériau, kg) | > Y : rémunération ; ≤ Y : point relais le plus proche + points en attente |
| SCAN_AT_RELAY(decl_id) | Crédite les points, renvoie le solde avant/après |
| PLAN_COLLECTION_ROUTE(commune, arrêts, jours) | Tournée optimisée (plus proche voisin + 2-opt) + note Cortex |
| KPI_SUMMARY, KPI_BY_COMMUNE, KPI_BY_MATERIAL, KPI_DAILY | KPIs de la simulation |

Données synthétiques (GENERATOR) : 500 ménages, 200 commerçants, 6 communes, 18 points relais, ~4 200 apports, 120 signalements.

## 2. API
```bash
cd api
cp .env.example .env.local   # compte, utilisateur, mot de passe ou clé privée
npm install
npm run dev                  # http://localhost:4000
```

| Méthode | Route | Corps / paramètres | Réponse |
|---|---|---|---|
| POST | `/api/reports` | `{userId, lat, lon, imageBase64, mimeType}` | `{reportId, path, analysis}` (analyse IA) |
| GET | `/api/reports` | — | Signalements : GPS, date, heure, URL photo présignée, analyse IA |
| POST | `/api/declarations` | `{userId, material: CARTON\|PLASTIQUE\|ALUMINIUM, weightKg}` | Rémunération ou point relais + points en attente |
| GET | `/api/declarations?userId=` | — | 10 dernières déclarations |
| POST | `/api/scan` | `{declId}` | `{balance_before, points_added, balance_after, …}` |
| GET | `/api/route-plan?commune=TOUTES&stops=12&days=7` | — | Arrêts ordonnés, km, gain, coût, note IA |
| GET | `/api/kpis` | — | Tonnage, coût de collecte, rémunérations, points (global, par commune, matériau, jour) |
| GET | `/api/users?type=MENAGE\|COMMERCANT&q=` | — | Usagers de démo |
| GET | `/api/config` | — | Seuil Y, prix, points relais |

Exemples :
```bash
curl -X POST localhost:4000/api/declarations -H 'Content-Type: application/json' \
     -d '{"userId":"C0001","material":"ALUMINIUM","weightKg":80}'        # → 24 000 F CFA
curl -X POST localhost:4000/api/declarations -H 'Content-Type: application/json' \
     -d '{"userId":"M0001","material":"PLASTIQUE","weightKg":4.5}'      # → point relais, 45 points
curl -X POST localhost:4000/api/scan -H 'Content-Type: application/json' -d '{"declId":"<decl_id>"}'
curl "localhost:4000/api/route-plan?commune=Cocody&stops=8"
```

CORS : `CORS_ORIGIN` (défaut `*`) — mettez l'URL de votre frontend en production.
Toutes les requêtes SQL sont paramétrées ; les identifiants Snowflake restent côté serveur.
